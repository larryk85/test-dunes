#!/bin/sh

pandoc dunes.1.md -s -t man -o dunes.1