## DUNES plugins

This directory contains DUNES example plugins. To test the example plugins, copy or symbolically link the contents of the [../plugin_example/](../plugin_example) directory into the [../src/plugin/](../src/plugin/) directory. This way, DUNES will automatically discover the new plugins.

For more information please check [plugin documentation](../docs/PLUGIN.md)